import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import ttest_ind

# -------------------------------
# Load the dataset
# -------------------------------
df = pd.read_csv("last_mile_delivery_dataset.csv")

# -------------------------------
# Clean city names
# Removes extra spaces and converts names to Title Case
# Example: " delhi " -> "Delhi", "MUMBAI" -> "Mumbai"
# -------------------------------
df["city"] = df["city"].str.strip().str.title()

# -------------------------------
# Basic dataset information
# -------------------------------
print("First 5 Rows:")
print(df.head())

print("\nDataset Shape:")
print(df.shape)

print("\nDataset Info:")
print(df.info())

print("\nMissing Values:")
print(df.isnull().sum())

# -------------------------------
# Data Cleaning
# -------------------------------

# Fill missing values in categorical columns
df["zone"] = df["zone"].fillna("Unknown")
df["rider_id"] = df["rider_id"].fillna("Not_Assigned")

# Fill missing GPS coordinates with median values
df["gps_latitude"] = df["gps_latitude"].fillna(df["gps_latitude"].median())
df["gps_longitude"] = df["gps_longitude"].fillna(df["gps_longitude"].median())

print("\nMissing Values After Cleaning:")
print(df.isnull().sum())

# -------------------------------
# Q1: Peak Hour Delay Analysis
# -------------------------------

df["order_time"] = pd.to_datetime(df["order_time"], format="%H:%M")
df["hour"] = df["order_time"].dt.hour

df["peak"] = df["hour"].apply(
    lambda x: "Peak" if (8 <= x <= 10) or (17 <= x <= 20) else "Off-Peak"
)

print("\nQ1: Average Delay by Peak Hours")
print(df.groupby("peak")["delay_mins"].mean())

# -------------------------------
# Q2: Weather vs Delay Analysis
# -------------------------------

print("\nQ2: Median Delay by Weather Condition")
print(df.groupby("weather_condition")["delay_mins"].median())

rain_orders = df[df["weather_condition"] == "Rain"]

print("\nRain Condition - Median Delay by Order Type")
print(rain_orders.groupby("order_type")["delay_mins"].median())

# -------------------------------
# Q3: Rider Experience Analysis
# -------------------------------

under2 = df[df["rider_experience_yrs"] < 2]["delay_mins"]
over4 = df[df["rider_experience_yrs"] > 4]["delay_mins"]

print("\nAverage Delay (Experience < 2 Years):", under2.mean())
print("Average Delay (Experience > 4 Years):", over4.mean())

t_stat, p_value = ttest_ind(under2, over4)

print("T-Statistic:", t_stat)
print("P-Value:", p_value)

# -------------------------------
# Q4: Dashboard Visualizations
# -------------------------------

df["order_date"] = pd.to_datetime(df["order_date"])
df["month"] = df["order_date"].dt.month

# City-wise Average Delay
city_delay = df.groupby("city")["delay_mins"].mean()

plt.figure(figsize=(8, 5))
city_delay.plot(kind="bar")
plt.title("City-wise Average Delay")
plt.xlabel("City")
plt.ylabel("Average Delay (Minutes)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Monthly Average Delay
monthly_delay = df.groupby("month")["delay_mins"].mean()

plt.figure(figsize=(8, 5))
monthly_delay.plot(marker="o")
plt.title("Monthly Average Delay Trend")
plt.xlabel("Month")
plt.ylabel("Average Delay (Minutes)")
plt.grid(True)
plt.tight_layout()
plt.show()

# Vehicle-wise Average Delay
vehicle_delay = df.groupby("vehicle_type")["delay_mins"].mean()

plt.figure(figsize=(8, 5))
vehicle_delay.plot(kind="bar")
plt.title("Vehicle Type vs Average Delay")
plt.xlabel("Vehicle Type")
plt.ylabel("Average Delay (Minutes)")
plt.tight_layout()
plt.show()

# -------------------------------
# Final Summary
# -------------------------------

print("\n========== FINAL SUMMARY ==========")
print("1. Peak hour deliveries have significantly higher delays than off-peak deliveries.")
print("2. Fog and Rain cause much higher delays compared to clear weather.")
print("3. Medicine orders experience the highest delays during rain.")
print("4. Rider experience (<2 years vs >4 years) does not show a statistically significant difference.")
print("5. Increasing rider availability during peak hours and improving routing in bad weather can reduce delays.")